const AppName = "fpa";
AllFetchArr = [];

const error_msg = document.getElementById("error-msdid");

// Onload run fetch data
document.addEventListener("DOMContentLoaded", () => {
 showLoaderWhile(RenderBudgetTable("Budget_Manager_Items_Js", "",AllFetchArr, defaults="budgetItems"))

//  RenderBudgetTable("All_Budget_Managers_Js", "",AllFetchArr, defaults="budgetItems")
//  fetch("All_Budget_Managers_Js", "", AllFetchArr)
});

// Fetch Records
async function fetch(ReportName, recordCursor, AllFetchArr){
    try{
        let criteriaVar = "";
        if(ReportName === "Budget_Manager_Items_Js" && recordCursor != "prefilbudget" && recordCursor != "Assumption_budget"){
            
            criteriaVar = "(Budget_Manager != null)"
        }
        else if(ReportName === "COA_Report" && AllFetchArr.length  === 0 && recordCursor != "prefilbudget" && recordCursor != "Assumption_budget"){
            criteriaVar = "(Class.Class != \"EQUITY\" && Class.Class != \"LIABILITY\" && Class.Class != \"ASSET\" && Status == \"ACTIVE\")"
        }
        else if(ReportName === "Budget_Manager_Items_Js" && AllFetchArr.length  > 0  && recordCursor === "prefilbudget" || recordCursor === "Assumption_budget"){
            criteriaVar = "(Budget_Manager == "+AllFetchArr[0]+")"
            recordCursor = "";
            AllFetchArr = [];
        }
         var config = {
            app_name: AppName,
            report_name: ReportName,
            criteria: criteriaVar,
            record_cursor : recordCursor,
            max_records : 1000
        };
        const fetchResp = await ZOHO.CREATOR.DATA.getRecords(config);
        if(fetchResp){
            if(fetchResp.code == 3000){
                var MainData =  fetchResp.data;
                // push arr for get another set of records, if data available.
                AllFetchArr.push(MainData)
                if(fetchResp.record_cursor){
                    // Get the next batch record from zoho report
                    return await fetch(ReportName, fetchResp.record_cursor, AllFetchArr);
                }
                else{
                    let Arr_merged = AllFetchArr.flat();
                    // get only items arr for pagination
                    // const budgetItems = Arr_merged.flatMap(obj => obj.Budget_Items);
                    // console.log("budgetItems - ",Arr_merged);
                    if(ReportName === "Budget_Manager_Items_Js" && recordCursor != "prefilbudget" && recordCursor != "Assumption_budget"){
                        // Store array for searching and resue lookup
                        const budgetItemsData_cached = localStorage.getItem('budgetItemsData');
                        if (budgetItemsData_cached) {
                            localStorage.removeItem('budgetItemsData');
                        }
                        localStorage.setItem('budgetItemsData', JSON.stringify(Arr_merged));
                    }
                    return Arr_merged;
                }
            }
            else{
                console.log("No Record found - ",fetchResp)
            }
        }
        else{
            console.log("Fetch API Error")
        }
    }
    catch (err)
    {
        console.log("zoho init error = ", err)
    }
}

// Update API
function UpdateRecordByID(ReportName,RecID, customer_Arr){
    let payload = "";
    try{
        if(ReportName === "Budget_Manager_Items_Js" && customer_Arr){
            payload = {
                "data":
                {
                    "Customer" : customer_Arr.Customer,
                    "January" : customer_Arr.January,
                    "February" : customer_Arr.February,
                    "March" : customer_Arr.March,
                    "April" : customer_Arr.April,
                    "May" : customer_Arr.May,
                    "June" : customer_Arr.June,
                    "July" : customer_Arr.July,
                    "August" : customer_Arr.August,
                    "September" : customer_Arr.September,
                    "October" : customer_Arr.October,
                    "November" : customer_Arr.November,
                    "December" : customer_Arr.December,
                    UpdateRecordsJs : true
                }
            }
        }
        var UpdateRec_config = {
                app_name: AppName,
                report_name: ReportName,
                id: RecID,
                payload: payload
            };
        ZOHO.CREATOR.DATA.updateRecordById(UpdateRec_config).then(function (Update_response) {
            if (Update_response.code == 3000) {

                // // Call budget sycn to analytics
                // if(ReportName === "Budget_Manager_Items_Js" && customer_Arr){
                //      POSTRecord("Pnl_Schedule", []);
                // }

                
                let AllFetchArr = [];
                showLoaderWhile(RenderBudgetTable("Budget_Manager_Items_Js", "", AllFetchArr, defaults="budgetItems"));
                
                // Submit Response
                errorMsg("Item Updated.", "green")

            } 
            else{
                console.log("Update rec error = ",Update_response)
            }
        });
        
    }
    catch (err){
         console.log("zoho init error for update = ", err)
    }

}

// Delete ApI
function DeleteRecordByID(ReportName, RecID){
    try{
        var Deleteconfig = {
            app_name: AppName,
            report_name: ReportName,
            id: RecID
        };
        ZOHO.CREATOR.DATA.deleteRecordById(Deleteconfig).then(function (Delete_response) {
        if (Delete_response.code == 3000) {
            let AllFetchArr = [];
            showLoaderWhile(RenderBudgetTable("Budget_Manager_Items_Js", "",AllFetchArr, defaults="budgetItems"))

            // Submit Response
            setTimeout(() => {
                errorMsg("Item Deleted.", "green")
            }, 3000);
        }
        else{
                console.log("Deleted rec error = ",Delete_response)
            }
        });
    }
    catch (err){
        console.log("zoho init error for update = ", err)
    }
}

// Post API
async function POSTRecord(FormName, customer_Arr){
    let payload = "";
    try{
        if(FormName === "Budget_Manager_Items" && customer_Arr){
            payload = {
                "data":
                {
                    "Customer" : customer_Arr.Customer,
                    "Class" : customer_Arr.categoryID,
                    "Account_Name" :customer_Arr.account,
                    "Budget_Manager" :customer_Arr.budgetId,
                    "Year_field" : customer_Arr.year,
                    "January" : customer_Arr.January,
                    "February" : customer_Arr.February,
                    "March" : customer_Arr.March,
                    "April" : customer_Arr.April,
                    "May" : customer_Arr.May,
                    "June" : customer_Arr.June,
                    "July" : customer_Arr.July,
                    "August" : customer_Arr.August,
                    "September" : customer_Arr.September,
                    "October" : customer_Arr.October,
                    "November" : customer_Arr.November,
                    "December" : customer_Arr.December,
                     UpdateRecordsJs : true
                }
            }
        }
        else if(FormName === "Budget_Manager" && customer_Arr){
            payload = {
                "data":
                {
                    "Name" : customer_Arr.name,
                    "Year_field" : customer_Arr.year,
                    "Start_Month" :customer_Arr.month,
                    "Period" : customer_Arr.period,
                    UpdateRecordsJs : true
                }
            }
        }
        // else if(FormName === "Pnl_Schedule"){
        //     payload = {
        //         "data":
        //         {
        //             "Name" : "JSBudgetUpdateAnalytics",
        //             "Start_Time" :getCurrentDateTimeDDMMYYYY(0,10)
        //         }
        //     }
        // }
        var postRec_config = {
            app_name: AppName,
            form_name: FormName,
            payload: payload
        };
        const post_response = await ZOHO.CREATOR.DATA.addRecords(postRec_config);
        if (post_response.code == 3000) {
            // Call budget sycn to analytics
            // if(FormName === "Budget_Manager_Items"){
            //     POSTRecord("Pnl_Schedule", []);
            // }
            return post_response
        }
        else{
            console.log("POST rec error = ",post_response)
            return post_response
        }    
    }
    catch (err){
         console.log("zoho init error for update = ", err)
         return err
    }
}

// Post Bulk API
async function POSTBulkRecord(FormName, inputArr){
     let payload = "";
    try{
        if(FormName === "Budget_Manager_Items" && inputArr){
            payload = {
                "data": inputArr
            }
        }
        var postRec_config = {
            app_name: AppName,
            form_name: FormName,
            private_link : "v880yEkuP3seQCT7fOhvJgG0WgdY29hFudt5yAKw9YarRE6wYXGBVw21jCmxgAyRMV4KT5nuMsW5EYZ1tU81sCA3wx8vPkh402bA",
            payload: payload
        };
        const post_response = await ZOHO.CREATOR.PUBLISH.addRecords(postRec_config);
        if (post_response.code == 3000) {
            // if(FormName === "Budget_Manager_Items"){
            //     POSTRecord("Pnl_Schedule", []);
            // }
            return post_response
        }
        else{
            console.log("POST Bulk rec error = ",post_response)
            return post_response
        }    
    }
    catch (err){
         console.log("zoho init error for update = ", err)
         return err
    }
}

//DateTime formate
// function getCurrentDateTimeDDMMYYYY(addMins = 0, addSecs = 0) {
//   const now = new Date();

//   // Add minutes and seconds if passed
//   now.setMinutes(now.getMinutes() + addMins);
//   now.setSeconds(now.getSeconds() + addSecs);

//   const day = String(now.getDate()).padStart(2, '0');
//   let month = now.toLocaleString('default', { month: 'short' });
//   if (month === "Sept") month = "Sep"; // normalize to 3-letter format
//   const year = now.getFullYear();

//   const hours = String(now.getHours()).padStart(2, '0');
//   const mins = String(now.getMinutes()).padStart(2, '0');
//   const secs = String(now.getSeconds()).padStart(2, '0');

//   return `${day}-${month}-${year} ${hours}:${mins}:${secs}`;
// }